# LearnLab 评审运行说明

> LearnLab 跨学科智能学习平台（AIC 算法创新赛·AI+学科交叉）
> 本文面向评审人员，说明两种体验方式：在线环境直接访问（推荐），或在本地从源码运行完整系统。

## 1. 在线演示（推荐，无需部署）

平台已部署在腾讯云并持续运行：**https://www.dreamlast.cn**

- 学生端与教师端全部功能均可在线实际操作，AI 智能辅导、组卷等大模型能力已配置就绪；
- 登录页提供「体验学生账号」「体验教师账号」一键进入（账号见第 6 节，线上线下通用）；
- 教师端「试点数据分析」页面为平台真实运行数据的自动聚合报告，支持一键导出。

## 2. 环境要求（本地运行时）

| 组件 | 版本要求 | 说明 |
|---|---|---|
| 操作系统 | Windows 10/11 或 Linux | Windows 已验证 |
| Python | 3.11+ | 后端 |
| Node.js | 18+ | 前端构建 |
| 浏览器 | Chrome / Edge | 访问前端 |

无需安装 MySQL/PostgreSQL：系统默认使用 SQLite（随源码附带演示数据库），开箱即运行。

## 3. 目录结构

```text
learnlab/
├─ backend/               # FastAPI 后端
│  ├─ app/                # 应用源码（API/算法/智能体/模型）
│  ├─ ai_learning_v2.db   # SQLite 演示数据库（含演示账号与课程数据）
│  ├─ requirements.txt    # 依赖清单
│  └─ seed_data.py        # 演示数据初始化脚本（可选）
└─ frontend/              # React + Vite 前端
   ├─ src/                # 前端源码
   └─ package.json
```

## 4. 后端启动（约 2 分钟）

```bash
cd backend
python -m venv venv                      # 创建虚拟环境
venv\Scripts\activate                    # Windows 激活（Linux: source venv/bin/activate）
pip install -r requirements.txt           # 安装依赖
python -m uvicorn app.main:app --host 127.0.0.1 --port 8001
```

启动成功标志：控制台输出 `Uvicorn running on http://127.0.0.1:8001`，
访问 `http://127.0.0.1:8001/health` 返回 `{"status": "healthy"}`。

> AI 智能辅导、组卷等大模型能力通过 OpenAI 兼容接口接入，支持讯飞星火、DeepSeek、智谱、
> OpenAI、小米 MiMo 五家厂商配置与一键切换。在 `backend/.env` 中配置任一厂商的 API Key
> （如讯飞星火 `SPARK_API_KEY`）即可启用，约 1 分钟完成。算法评估与全部验证脚本
> （`backend/scripts/`、`backend/reports/`）离线可复现，不依赖外部服务，结果可审计。

## 5. 前端启动（约 2 分钟）

新开一个终端：

```bash
cd frontend
npm install                              # 安装依赖（首次约 2-5 分钟）
set VITE_PROXY_TARGET=http://127.0.0.1:8001   # Linux: export VITE_PROXY_TARGET=...
npm run dev                              # 开发模式启动
```

启动成功标志：控制台输出 `Local: http://localhost:5173/`。

## 6. 访问与演示账号

浏览器打开 `http://localhost:5173`（或直接访问线上环境 https://www.dreamlast.cn）：

| 角色 | 账号 | 密码 |
|---|---|---|
| 学生 | student_001 | 123456 |
| 教师 | T001 | Teacher123 |

**最快捷的进入方式**：登录页下方提供「体验学生账号」「体验教师账号」两个按钮，点击即登录，无需手动输入。也可按上表手动输入账号密码，或在登录页自行注册新的学生账号。

## 7. 建议的评审演示路径（约 10 分钟，线上或本地任一环境均可）

1. **学生端**：登录 student_001 → 学习仪表盘 → 学习路径（16 阶段个性化计划）→ 学习中心（图文讲义 + 康奈尔线索栏 + AI 助手三栏阅读视图，正文区滚动阅读，右上角「标记完成」触发知识库自动整理与成就解锁）
2. **AI 能力**：智能辅导（提问后 AI 苏格拉底式流式回复）→ 错误诊断（粘贴含错误 C 代码，自动语法/逻辑/思维误区分析）
3. **游戏化**：知识冒险（挑战地图）→ 多维排行榜（6 维度）
4. **教师端**：退出后以 T001 登录 → 教师工作台（全班学情）→ AI 智能组卷（输入主题自动生成试卷）→ 试点数据分析（应用效果实测数据，支持一键导出报告）

## 8. 常见问题

- **端口占用**：后端默认 8001、前端默认 5173，后端可在启动命令中修改 `--port`，前端端口在 `vite.config.ts` 中调整。
- **npm install 缓慢**：可切换国内镜像 `npm config set registry https://registry.npmmirror.com`。
- **AI 功能未生效**：在 `backend/.env` 中配置 API Key（如 `SPARK_API_KEY`）后重启后端即可；多家厂商 Key 可随时切换对比。
- **数据库重置**：删除 `backend/ai_learning_v2.db` 后运行 `python seed_data.py` 可重建演示数据。

## 9. 算法验证与复现（可选）

`backend/reports/algorithm_evaluation.md` 记录了 AIC 算法增强（BKT/GKT/IRT/NCD/FSRS/MAB）的
离线评估结果与复现方式；`backend/scripts/verify_ai_algorithms.py` 可一键重新验证，全部验证
脚本随源码包交付，评审可独立复现。
