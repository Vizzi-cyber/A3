"""
学习日志与自我反思API
- 学习日志自动记录
- 反思记录存储与查询
- 学习复盘数据接口
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from ..models.database import get_db
from ..models.log_reflection import LearningLogModel, ReflectionModel
from ..services.path_adjustment_engine import maybe_check_path_adjustment
from .auth import require_auth

router = APIRouter()


# ---------- 学习日志 ----------

@router.get("/{student_id}/logs")
async def get_learning_logs(student_id: str, date: Optional[str] = None, db: Session = Depends(get_db), _current: str = Depends(require_auth)):
    """获取学习日志"""
    if student_id != _current:
        raise HTTPException(status_code=403, detail="Cannot view other student's logs")
    query = db.query(LearningLogModel).filter(LearningLogModel.student_id == student_id)
    if date:
        query = query.filter(LearningLogModel.date == date)
    logs = query.order_by(LearningLogModel.date.desc()).limit(100).all()
    return {
        "status": "success",
        "data": [
            {
                "log_id": l.log_id,
                "date": l.date,
                "total_duration": l.total_duration,
                "kp_count": l.kp_count,
                "quiz_count": l.quiz_count,
                "avg_score": l.avg_score,
                "mistakes": l.mistakes,
                "path_progress": l.path_progress,
                "completed_tasks": l.completed_tasks,
                "timeline": l.timeline,
            }
            for l in logs
        ],
    }


class UpsertLogRequest(BaseModel):
    student_id: str
    date: str = Field(..., pattern=r"^\d{4}-\d{2}-\d{2}$")
    total_duration: int = Field(0, ge=0, le=86400)
    kp_count: int = Field(0, ge=0, le=10000)
    quiz_count: int = Field(0, ge=0, le=10000)
    avg_score: float = Field(0.0, ge=0.0, le=100.0)
    mistakes: List[str] = Field(default_factory=list, max_length=1000)
    path_progress: float = Field(0.0, ge=0.0, le=1.0)
    completed_tasks: List[str] = Field(default_factory=list, max_length=1000)
    timeline: List[Dict[str, Any]] = Field(default_factory=list, max_length=5000)


@router.post("/logs/upsert")
async def upsert_learning_log(request: UpsertLogRequest, db: Session = Depends(get_db), _current: str = Depends(require_auth)):
    """创建或更新学习日志"""
    if request.student_id != _current:
        raise HTTPException(status_code=403, detail="Cannot modify other student's logs")
    existing = db.query(LearningLogModel).filter(
        LearningLogModel.student_id == request.student_id,
        LearningLogModel.date == request.date,
    ).first()
    if existing:
        existing.total_duration = request.total_duration
        existing.kp_count = request.kp_count
        existing.quiz_count = request.quiz_count
        existing.avg_score = request.avg_score
        existing.mistakes = request.mistakes
        existing.path_progress = request.path_progress
        existing.completed_tasks = request.completed_tasks
        existing.timeline = request.timeline
        db.commit()
        return {"status": "success", "message": "Log updated"}
    log = LearningLogModel(
        log_id=f"log_{request.student_id}_{request.date}",
        student_id=request.student_id,
        date=request.date,
        total_duration=request.total_duration,
        kp_count=request.kp_count,
        quiz_count=request.quiz_count,
        avg_score=request.avg_score,
        mistakes=request.mistakes,
        path_progress=request.path_progress,
        completed_tasks=request.completed_tasks,
        timeline=request.timeline,
    )
    db.add(log)
    db.commit()
    return {"status": "success", "message": "Log created"}


# ---------- 反思记录 ----------

class ReflectionCreateRequest(BaseModel):
    student_id: str
    date: str = Field(..., pattern=r"^\d{4}-\d{2}-\d{2}$")
    content: str = Field(..., min_length=1, max_length=20000)
    mood: str = Field("neutral", pattern="^(happy|neutral|frustrated|excited)$")
    tags: List[str] = Field(default_factory=list, max_length=50)
    ai_feedback: Optional[str] = Field(None, max_length=20000)


@router.post("/reflections/create")
async def create_reflection(request: ReflectionCreateRequest, db: Session = Depends(get_db), _current: str = Depends(require_auth)):
    """
    创建反思 / 笔记记录。
    每次调用都会生成新的 reflection_id（含毫秒时间戳 + 主标签），
    避免 cornell / feynman / 普通反思同日互相覆盖。
    """
    if request.student_id != _current:
        raise HTTPException(status_code=403, detail="Cannot create reflection for other student")
    # 主标签：tags 中第一个非通用值，或 'reflection'
    primary_tag = "reflection"
    for t in (request.tags or []):
        if t and t not in ("notes",):
            primary_tag = str(t)
            break
    ts_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    reflection_id = f"ref_{request.student_id}_{request.date}_{primary_tag}_{ts_ms}"
    ref = ReflectionModel(
        reflection_id=reflection_id,
        student_id=request.student_id,
        date=request.date,
        content=request.content,
        mood=request.mood,
        tags=request.tags,
        ai_feedback=request.ai_feedback,
    )
    db.add(ref)
    db.commit()

    # 检查是否需要调整路径
    await maybe_check_path_adjustment(request.student_id, db)

    return {"status": "success", "reflection_id": reflection_id}


class ReflectionUpdateRequest(BaseModel):
    content: Optional[str] = None
    mood: Optional[str] = None
    tags: Optional[List[str]] = None
    ai_feedback: Optional[str] = None


@router.put("/reflections/{reflection_id}")
async def update_reflection(reflection_id: str, request: ReflectionUpdateRequest, db: Session = Depends(get_db), _current: str = Depends(require_auth)):
    """更新指定反思 / 笔记"""
    ref = db.query(ReflectionModel).filter(ReflectionModel.reflection_id == reflection_id).first()
    if not ref:
        raise HTTPException(status_code=404, detail="reflection not found")
    if ref.student_id != _current:
        raise HTTPException(status_code=403, detail="Not authorized to update this reflection")
    if request.content is not None:
        ref.content = request.content
    if request.mood is not None:
        ref.mood = request.mood
    if request.tags is not None:
        ref.tags = request.tags
    if request.ai_feedback is not None:
        ref.ai_feedback = request.ai_feedback
    db.commit()
    return {"status": "success", "reflection_id": reflection_id}


@router.delete("/reflections/{reflection_id}")
async def delete_reflection(reflection_id: str, db: Session = Depends(get_db), _current: str = Depends(require_auth)):
    """删除指定反思 / 笔记"""
    ref = db.query(ReflectionModel).filter(ReflectionModel.reflection_id == reflection_id).first()
    if not ref:
        raise HTTPException(status_code=404, detail="reflection not found")
    if ref.student_id != _current:
        raise HTTPException(status_code=403, detail="Not authorized to delete this reflection")
    db.delete(ref)
    db.commit()
    return {"status": "success", "reflection_id": reflection_id}


@router.get("/{student_id}/reflections")
async def get_reflections(student_id: str, limit: int = Query(30, ge=1, le=100), db: Session = Depends(get_db), _current: str = Depends(require_auth)):
    """获取反思记录列表"""
    if student_id != _current:
        raise HTTPException(status_code=403, detail="Cannot view other student's reflections")
    refs = (
        db.query(ReflectionModel)
        .filter(ReflectionModel.student_id == student_id)
        .order_by(ReflectionModel.date.desc(), ReflectionModel.created_at.desc())
        .limit(limit)
        .all()
    )
    return {
        "status": "success",
        "data": [
            {
                "reflection_id": r.reflection_id,
                "date": r.date,
                "content": r.content,
                "mood": r.mood,
                "tags": r.tags,
                "ai_feedback": r.ai_feedback,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in refs
        ],
    }


@router.get("/{student_id}/review")
async def get_learning_review(student_id: str, db: Session = Depends(get_db), _current: str = Depends(require_auth)):
    """学习复盘数据接口（聚合日志与反思）"""
    if student_id != _current:
        raise HTTPException(status_code=403, detail="Cannot view other student's review")
    logs = (
        db.query(LearningLogModel)
        .filter(LearningLogModel.student_id == student_id)
        .order_by(LearningLogModel.date.desc())
        .limit(7)
        .all()
    )
    refs = (
        db.query(ReflectionModel)
        .filter(ReflectionModel.student_id == student_id)
        .order_by(ReflectionModel.date.desc())
        .limit(7)
        .all()
    )
    total_duration = sum(l.total_duration for l in logs)
    avg_score = sum(l.avg_score for l in logs) / len(logs) if logs else 0.0
    return {
        "status": "success",
        "student_id": student_id,
        "review_period_days": len(logs),
        "summary": {
            "total_duration": total_duration,
            "total_kps": sum(l.kp_count for l in logs),
            "total_quizzes": sum(l.quiz_count for l in logs),
            "avg_score": round(avg_score, 2),
            "reflection_count": len(refs),
        },
        "daily_logs": [
            {
                "date": l.date,
                "duration": l.total_duration,
                "kp_count": l.kp_count,
                "quiz_count": l.quiz_count,
                "avg_score": l.avg_score,
                "mistakes": l.mistakes,
                "path_progress": l.path_progress,
            }
            for l in logs
        ],
        "reflections": [
            {
                "date": r.date,
                "mood": r.mood,
                "tags": r.tags,
                "content_preview": r.content[:100] + "..." if r.content and len(r.content) > 100 else r.content,
            }
            for r in refs
        ],
    }
