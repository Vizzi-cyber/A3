"""
用户权限API
- 登录、注册、token管理
- JWT身份校验
"""
import asyncio
import re
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Header
from jose import jwt, JWTError
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
import bcrypt

from ..core.config import settings
from ..core.logger import setup_logger
from ..models.database import get_db
from ..models.user import UserModel

logger = setup_logger()

router = APIRouter()


def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def _verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def _validate_password_strength(password: str) -> str:
    if not re.search(r"[A-Za-z]", password):
        raise ValueError("密码必须包含至少一个字母")
    if not re.search(r"\d", password):
        raise ValueError("密码必须包含至少一个数字")
    return password

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_DAYS = 7

class UserRegisterRequest(BaseModel):
    student_id: str = Field(..., min_length=3, max_length=64)
    username: str = Field(..., min_length=1, max_length=128)
    email: Optional[str] = None
    password: str = Field(..., min_length=8, max_length=128)

    @field_validator("password")
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        return _validate_password_strength(v)


class UserLoginRequest(BaseModel):
    student_id: str = Field(..., min_length=3, max_length=64)
    password: str = Field(..., min_length=1, max_length=128)


class PasswordChangeRequest(BaseModel):
    current_password: str = Field(..., min_length=1, max_length=128)
    new_password: str = Field(..., min_length=8, max_length=128)

    @field_validator("new_password")
    @classmethod
    def validate_new_password_strength(cls, v: str) -> str:
        return _validate_password_strength(v)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


def _create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(days=ACCESS_TOKEN_EXPIRE_DAYS))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=ALGORITHM)


def _verify_token(token: str) -> Optional[str]:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("sub")
    except JWTError as e:
        logger.debug(f"JWT校验失败: {e}")
        return None


from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer(auto_error=False)

async def get_current_student_id(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> str:
    """依赖注入：从请求头提取并校验token，未认证时抛401"""
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = credentials.credentials
    student_id = _verify_token(token)
    if not student_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return student_id


async def require_auth(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> str:
    """严格认证：无token或token无效时直接抛401"""
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = credentials.credentials
    student_id = _verify_token(token)
    if not student_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return student_id


async def require_teacher(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: Session = Depends(get_db),
) -> str:
    """教师权限认证：验证token且role为teacher或admin"""
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = credentials.credentials
    student_id = _verify_token(token)
    if not student_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.query(UserModel).filter(UserModel.student_id == student_id).first()
    if not user or not user.is_active or user.role not in ("teacher", "admin"):
        raise HTTPException(status_code=403, detail="教师权限不足")
    return student_id


async def require_admin(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: Session = Depends(get_db),
) -> str:
    """管理员权限认证。"""
    student_id = await require_auth(credentials)
    user = db.query(UserModel).filter(UserModel.student_id == student_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=403, detail="管理员权限不足")
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="管理员权限不足")
    return student_id


def verify_token(token: str) -> Optional[str]:
    """公开token校验函数，供其他模块使用"""
    return _verify_token(token)


def verify_student_ownership(requested_id: str, current_id: str) -> None:
    """校验请求的 student_id 是否等于当前认证用户，否则抛 403"""
    if requested_id != current_id:
        raise HTTPException(status_code=403, detail="无权操作其他用户的数据")


def verify_student_access(requested_id: str, current_id: str, db: Session) -> None:
    """允许本人或教师/管理员访问学生数据。"""
    if requested_id == current_id:
        return
    user = db.query(UserModel).filter(UserModel.student_id == current_id).first()
    if not user or not user.is_active or user.role not in ("teacher", "admin"):
        raise HTTPException(status_code=403, detail="无权操作其他用户的数据")


def verify_token_for_websocket(token: Optional[str]) -> Optional[str]:
    """用于WebSocket的token校验（不抛HTTP异常，返回None表示失败）"""
    if not token:
        return None
    return _verify_token(token)


@router.post("/register")
async def register(request: UserRegisterRequest, db: Session = Depends(get_db)):
    """用户注册"""
    existing = db.query(UserModel).filter(UserModel.student_id == request.student_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="student_id already exists")
    hashed = _hash_password(request.password)
    user = UserModel(
        student_id=request.student_id,
        username=request.username,
        email=request.email,
        hashed_password=hashed,
        is_active=True,
        role="student",
    )
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="student_id or email already exists")
    db.refresh(user)
    return {"status": "success", "message": "User registered", "student_id": user.student_id}


# 临时调试端点：仅 DEBUG 模式可用
@router.post("/_debug/validate-password")
async def debug_validate(password: str):
    from ..core.config import settings
    if not settings.DEBUG:
        raise HTTPException(status_code=404, detail="Not found")
    try:
        UserRegisterRequest(student_id="debug", username="debug", password=password)
        return {"valid": True}
    except ValueError as e:
        return {"valid": False, "errors": [{"msg": str(e)}]}


@router.post("/register-teacher")
async def register_teacher(
    request: UserRegisterRequest,
    db: Session = Depends(get_db),
    invite_code: Optional[str] = Header(None, alias="X-Invite-Code"),
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
):
    """教师注册（邀请码 或 管理员身份二选一）"""
    authorized = False
    if credentials is not None:
        try:
            await require_admin(credentials, db)
            authorized = True
        except HTTPException:
            authorized = False
    if not authorized:
        expected = (settings.TEACHER_INVITE_CODE or "").strip()
        if not expected or (invite_code or "").strip() != expected:
            raise HTTPException(status_code=403, detail="邀请码错误或缺失")
    existing = db.query(UserModel).filter(UserModel.student_id == request.student_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="student_id already exists")
    hashed = _hash_password(request.password)
    user = UserModel(
        student_id=request.student_id,
        username=request.username,
        email=request.email,
        hashed_password=hashed,
        is_active=True,
        role="teacher",
    )
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="student_id or email already exists")
    db.refresh(user)
    return {"status": "success", "message": "Teacher registered", "student_id": user.student_id}


@router.post("/login", response_model=TokenResponse)
async def login(request: UserLoginRequest, db: Session = Depends(get_db)):
    """用户登录"""
    user = db.query(UserModel).filter(UserModel.student_id == request.student_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    valid = _verify_password(request.password, user.hashed_password)
    if not valid:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = _create_access_token({"sub": user.student_id})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_EXPIRE_DAYS * 86400,
    }


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: Session = Depends(get_db),
):
    """刷新访问令牌（滑动续期）：凭当前有效 token 换发新 token。

    与现有单 token 架构一致——旧 token 未过期即可续期；查库校验 is_active
    使被禁用账号无法续期。token 已过期时返回 401，前端应引导重新登录。
    """
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    student_id = _verify_token(credentials.credentials)
    if not student_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.query(UserModel).filter(UserModel.student_id == student_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Account disabled or not found")
    token = _create_access_token({"sub": user.student_id})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_EXPIRE_DAYS * 86400,
    }


@router.get("/me")
async def get_me(student_id: str = Depends(get_current_student_id), db: Session = Depends(get_db)):
    """获取当前用户信息"""
    user = db.query(UserModel).filter(UserModel.student_id == student_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {
        "status": "success",
        "data": {
            "student_id": user.student_id,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "is_active": user.is_active,
        },
    }


@router.post("/change-password")
async def change_password(
    request: PasswordChangeRequest,
    student_id: str = Depends(get_current_student_id),
    db: Session = Depends(get_db),
):
    """Change only the authenticated user's password after verifying it."""
    user = db.query(UserModel).filter(UserModel.student_id == student_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=404, detail="User not found")
    if not user.hashed_password or not _verify_password(
        request.current_password, user.hashed_password
    ):
        raise HTTPException(status_code=400, detail="当前密码不正确")
    if _verify_password(request.new_password, user.hashed_password):
        raise HTTPException(status_code=400, detail="新密码不能与当前密码相同")

    user.hashed_password = _hash_password(request.new_password)
    try:
        db.commit()
    except Exception:
        db.rollback()
        logger.exception("Password change failed for user %s", student_id)
        raise HTTPException(status_code=500, detail="密码更新失败，请稍后重试")
    return {"status": "success", "message": "密码已更新，请重新登录"}
