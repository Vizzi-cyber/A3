"""
多维度加权匹配算法
场景1：学生 <-> 学习资源匹配（知识点、难度、风格、目标）
场景2：学生 <-> 学习路径匹配（基础水平、薄弱点、节奏、目标）
输出：匹配度得分、优先级排序、推荐列表
联动机制：趋势预警触发 -> 自动重新匹配

AIC 算法增强（P1-4）：资源匹配可叠加 Thompson Sampling 探索层——
  - 人工权重打分作为先验得分（保底可解释）
  - 学生对各类资源的历史收益（点击/完成）以 MAB 期望建模，按
    final = score + explore_weight · (E[arm] − 0.5) 混合，
    冷启动（E=0.5）时排序与纯打分完全一致，预热后偏好高收益资源类型
"""
from typing import Dict, Any, List, Tuple, Optional
import math

# 资源类型臂（Thompson Sampling 探索层；未知类型由 _resource_arm 归入 document）
RESOURCE_ARMS = ["video", "document", "quiz", "interactive", "audio", "image", "code", "mindmap"]


def resource_arm(res: Dict[str, Any]) -> str:
    """从资源 dict 提取类型臂标识。"""
    for key in ("type", "content_type", "category"):
        v = str(res.get(key) or "").strip().lower()
        if v:
            return v
    content_types = res.get("content_types") or []
    if content_types:
        return str(content_types[0]).strip().lower()
    return "document"


class MultiDimWeightedMatcher:
    """多维度加权匹配器"""

    # 资源匹配维度权重
    RESOURCE_WEIGHTS = {
        "knowledge_match": 0.30,
        "difficulty_fit": 0.25,
        "style_match": 0.20,
        "goal_match": 0.15,
        "tempo_match": 0.10,
    }

    # 路径匹配维度权重
    PATH_WEIGHTS = {
        "base_level_fit": 0.25,
        "weakness_coverage": 0.25,
        "tempo_fit": 0.20,
        "goal_alignment": 0.20,
        "prerequisite_ready": 0.10,
    }

    def match_resources(
        self,
        student_profile: Dict[str, Any],
        resources: List[Dict[str, Any]],
        top_k: int = 5,
        bandit_selector: Optional[Any] = None,
        explore_weight: float = 0.15,
        irt_difficulty: Optional[Dict[str, float]] = None,
        irt_ability: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        学生-学习资源匹配

        :param bandit_selector: 可选，Thompson Sampling 探索层（按资源类型臂）。
            预热后按 final = score + explore_weight·(E[arm]−0.5) 调序；
            未提供或冷启动时与纯打分排序完全一致（向后兼容）。
        :param irt_difficulty: 可选，IRT 标定的难度映射 {kp_id: b}（复合 item_id
            已按知识点前缀聚合）。提供时难度适配用 logistic(θ−b) 连续拟合分
            替代三档字符串匹配（difficulty_source = "irt_b"）。
        :param irt_ability: 可选，该生 IRT 能力 θ（缺省按 0 = 标定均值处理）。
        """
        exploration_enabled = (
            bandit_selector is not None
            and getattr(bandit_selector, "is_warm", False)
        )
        expectations = bandit_selector.get_expectations() if exploration_enabled else {}
        scored = []
        for res in resources:
            score, details = self._score_resource(
                student_profile, res,
                irt_b=(irt_difficulty or {}).get(res.get("kp_id") or ""),
                irt_theta=irt_ability,
            )
            arm = resource_arm(res)
            adjust = 0.0
            if exploration_enabled:
                adjust = explore_weight * (float(expectations.get(arm, 0.5)) - 0.5)
            final = min(1.0, max(0.0, score + adjust))
            scored.append({
                "resource_id": res.get("resource_id", ""),
                "title": res.get("title", ""),
                "match_score": round(final, 4),
                "details": {**details, "arm": arm, "exploration_adjust": round(adjust, 4)},
                "resource": res,
            })

        scored.sort(key=lambda x: x["match_score"], reverse=True)
        return {
            "type": "resource_matching",
            "student_id": student_profile.get("student_id", ""),
            "recommendations": scored[:top_k],
            "total_candidates": len(resources),
            "exploration": {
                "enabled": exploration_enabled,
                "weight": explore_weight,
                "bandit_stats": bandit_selector.get_stats() if bandit_selector is not None else None,
            },
        }

    def match_learning_paths(
        self,
        student_profile: Dict[str, Any],
        path_candidates: List[Dict[str, Any]],
        top_k: int = 3,
    ) -> Dict[str, Any]:
        """
        学生-学习路径匹配
        """
        scored = []
        for path in path_candidates:
            score, details = self._score_path(student_profile, path)
            scored.append({
                "path_id": path.get("path_id", ""),
                "title": path.get("title", ""),
                "match_score": round(score, 4),
                "details": details,
                "path": path,
            })

        scored.sort(key=lambda x: x["match_score"], reverse=True)
        return {
            "type": "path_matching",
            "student_id": student_profile.get("student_id", ""),
            "recommendations": scored[:top_k],
            "total_candidates": len(path_candidates),
        }

    def _score_resource(
        self,
        profile: Dict[str, Any],
        resource: Dict[str, Any],
        irt_b: Optional[float] = None,
        irt_theta: Optional[float] = None,
    ) -> Tuple[float, Dict[str, float]]:
        """为单个资源计算匹配分"""
        # 1. 知识点匹配
        kp_match = self._knowledge_match(
            profile.get("knowledge_base", {}),
            resource.get("kp_tags", []),
            profile.get("weak_areas", []),
        )

        # 2. 难度适配（IRT b 可用时用连续拟合分）
        diff_fit = self._difficulty_fit(
            profile.get("knowledge_level", "intermediate"),
            resource.get("difficulty", "medium"),
            irt_b=irt_b,
            irt_theta=irt_theta,
        )

        # 3. 认知风格匹配
        style_match = self._cognitive_style_match(
            profile.get("cognitive_style", {}),
            resource.get("content_types", []),
        )

        # 4. 学习目标匹配
        goal_match = self._goal_match(
            profile.get("learning_goals", []),
            resource.get("objectives", []),
        )

        # 5. 学习节奏匹配
        tempo_match = self._tempo_match(
            profile.get("learning_tempo", {}),
            resource.get("estimated_duration", 30),
        )

        total = (
            kp_match * self.RESOURCE_WEIGHTS["knowledge_match"]
            + diff_fit * self.RESOURCE_WEIGHTS["difficulty_fit"]
            + style_match * self.RESOURCE_WEIGHTS["style_match"]
            + goal_match * self.RESOURCE_WEIGHTS["goal_match"]
            + tempo_match * self.RESOURCE_WEIGHTS["tempo_match"]
        )

        return total, {
            "knowledge_match": round(kp_match, 4),
            "difficulty_fit": round(diff_fit, 4),
            "difficulty_source": "irt_b" if irt_b is not None else "manual",
            "style_match": round(style_match, 4),
            "goal_match": round(goal_match, 4),
            "tempo_match": round(tempo_match, 4),
        }

    def _score_path(
        self,
        profile: Dict[str, Any],
        path: Dict[str, Any],
    ) -> Tuple[float, Dict[str, float]]:
        """为单条路径计算匹配分"""
        # 1. 基础水平适配
        base_fit = self._base_level_fit(
            profile.get("knowledge_level", "intermediate"),
            path.get("required_level", "intermediate"),
        )

        # 2. 薄弱点覆盖度
        weak_coverage = self._weakness_coverage(
            profile.get("weak_areas", []),
            path.get("covered_kps", []),
        )

        # 3. 节奏适配
        tempo_fit = self._tempo_fit(
            profile.get("learning_tempo", {}),
            path.get("estimated_hours", 10),
        )

        # 4. 目标对齐
        goal_align = self._goal_alignment(
            profile.get("learning_goals", []),
            path.get("objectives", []),
        )

        # 5. 前置准备度
        prereq_ready = self._prerequisite_ready(
            profile.get("knowledge_base", {}),
            path.get("prerequisites", []),
        )

        total = (
            base_fit * self.PATH_WEIGHTS["base_level_fit"]
            + weak_coverage * self.PATH_WEIGHTS["weakness_coverage"]
            + tempo_fit * self.PATH_WEIGHTS["tempo_fit"]
            + goal_align * self.PATH_WEIGHTS["goal_alignment"]
            + prereq_ready * self.PATH_WEIGHTS["prerequisite_ready"]
        )

        return total, {
            "base_level_fit": round(base_fit, 4),
            "weakness_coverage": round(weak_coverage, 4),
            "tempo_fit": round(tempo_fit, 4),
            "goal_alignment": round(goal_align, 4),
            "prerequisite_ready": round(prereq_ready, 4),
        }

    # ---------- 子评分函数 ----------

    def _knowledge_match(self, knowledge_base: Dict, kp_tags: List[str], weak_areas: List[str]) -> float:
        if not kp_tags:
            return 0.5
        mastered = set(knowledge_base.keys())
        weak_set = set(weak_areas)
        tags_set = set(kp_tags)
        # 匹配到薄弱点加分，匹配到已掌握点减分（重复学习）
        weak_match = len(tags_set & weak_set) / len(tags_set) if tags_set else 0.0
        master_match = len(tags_set & mastered) / len(tags_set) if tags_set else 0.0
        return 0.3 + weak_match * 0.7 - master_match * 0.2

    def _difficulty_fit(
        self,
        student_level: str,
        resource_difficulty: str,
        irt_b: Optional[float] = None,
        irt_theta: Optional[float] = None,
    ) -> float:
        """难度适配分。

        传入 IRT 标定 b（该资源关联知识点的难度）与该生能力 θ 时，用
        2PL 逻辑斯蒂 P = σ(1.7·(θ−b)) 计算答对概率，取 4P(1−P) 作为适配分
        （难度与能力匹配时取峰值 1.0，过难/过易两侧衰减）——
        与路径规划 _difficulty_factor 的 IRT 接入口径一致。
        未标定时回退三档字符串匹配（medium 与中档同义）。
        """
        if irt_b is not None:
            theta = float(irt_theta) if irt_theta is not None else 0.0
            p = 1.0 / (1.0 + math.exp(-1.7 * (theta - float(irt_b))))
            return max(0.0, min(1.0, 4.0 * p * (1.0 - p)))
        levels = {
            "beginner": 1, "easy": 1, "elementary": 1,
            "intermediate": 2, "medium": 2,
            "advanced": 3, "hard": 3,
        }
        s = levels.get(str(student_level or "").lower(), 2)
        r = levels.get(str(resource_difficulty or "").lower(), 2)
        diff = abs(s - r)
        if diff == 0:
            return 1.0
        elif diff == 1:
            return 0.6
        return 0.2

    def _cognitive_style_match(self, cognitive_style: Dict, content_types: List[str]) -> float:
        primary = cognitive_style.get("primary", "visual") if isinstance(cognitive_style, dict) else "visual"
        type_map = {
            "visual": ["video", "diagram", "mindmap", "image"],
            "auditory": ["audio", "podcast", "lecture"],
            "reading": ["document", "article", "textbook"],
            "kinesthetic": ["interactive", "code", "quiz", "lab"],
        }
        preferred = set(type_map.get(primary, []))
        if not content_types:
            return 0.5
        matched = len(preferred & set(content_types)) / len(content_types)
        return 0.3 + matched * 0.7

    def _goal_match(self, learning_goals: List[Dict], resource_objectives: List[str]) -> float:
        if not learning_goals or not resource_objectives:
            return 0.5
        goal_texts = [g.get("title", "") for g in learning_goals if isinstance(g, dict)]
        goal_texts += [str(g) for g in learning_goals if not isinstance(g, dict)]
        goal_texts = [gt for gt in goal_texts if gt]  # 空串目标不参与匹配（"" in s 恒真会虚增匹配数）
        matched = 0
        for obj in resource_objectives:
            if not obj:
                continue
            for gt in goal_texts:
                if obj in gt or gt in obj:
                    matched += 1
                    break
        return 0.2 + (matched / len(resource_objectives)) * 0.8

    def _tempo_match(self, learning_tempo: Dict, estimated_duration: int) -> float:
        optimal = learning_tempo.get("optimal_session_duration", 45) if isinstance(learning_tempo, dict) else 45
        if optimal <= 0:
            optimal = 45
        ratio = estimated_duration / optimal
        if 0.5 <= ratio <= 1.5:
            return 1.0 - abs(ratio - 1.0)
        return 0.3

    def _base_level_fit(self, student_level: str, required_level: str) -> float:
        return self._difficulty_fit(student_level, required_level)

    def _weakness_coverage(self, weak_areas: List[str], covered_kps: List[str]) -> float:
        if not weak_areas:
            return 0.8  # 没有薄弱点，路径匹配度默认较高
        if not covered_kps:
            return 0.2
        covered = len(set(weak_areas) & set(covered_kps))
        return 0.2 + (covered / len(weak_areas)) * 0.8

    def _goal_alignment(self, learning_goals: List[Dict], path_objectives: List[str]) -> float:
        return self._goal_match(learning_goals, path_objectives)

    def _prerequisite_ready(self, knowledge_base: Dict, prerequisites: List[str]) -> float:
        if not prerequisites:
            return 1.0
        mastered = set(knowledge_base.keys())
        ready = len(set(prerequisites) & mastered)
        return ready / len(prerequisites)

    def _tempo_fit(self, learning_tempo: Dict, estimated_hours: int) -> float:
        weekly_capacity = learning_tempo.get("weekly_study_capacity", 10) if isinstance(learning_tempo, dict) else 10
        if weekly_capacity <= 0:
            weekly_capacity = 10
        ratio = estimated_hours / weekly_capacity
        if ratio <= 1.0:
            return 1.0
        elif ratio <= 1.5:
            return 0.7
        elif ratio <= 2.0:
            return 0.4
        return 0.2
