const WIKILINK_REGEX = /\[\[([^\[\]|#]+?)(?:#[^\[\]|]*)?(?:\|[^\[\]]*?)?\]\]/g;

export function extractWikilinks(content: string): string[] {
  const targets: string[] = [];
  let match;
  while ((match = WIKILINK_REGEX.exec(content)) !== null) {
    const target = match[1].trim();
    if (target && !targets.includes(target)) {
      targets.push(target);
    }
  }
  return targets;
}

export function resolveWikilink(
  target: string,
  notes: { note_id: string; title: string }[]
): string | null {
  const targetLower = target.toLowerCase();
  const candidates = notes.filter(
    (n) => n.title.toLowerCase() === targetLower
  );
  if (candidates.length === 0) return null;
  return candidates[0].note_id;
}

export function replaceWikilinks(
  content: string,
  notes: { note_id: string; title: string }[]
): string {
  return content.replace(WIKILINK_REGEX, (match, target) => {
    const noteId = resolveWikilink(target.trim(), notes);
    if (noteId) {
      return `[${target.trim()}](/knowledge-base?note=${noteId})`;
    }
    return match;
  });
}
